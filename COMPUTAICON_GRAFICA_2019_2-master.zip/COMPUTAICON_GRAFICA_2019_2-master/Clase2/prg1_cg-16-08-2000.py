
ls = [4,6,7,'ana',[1,2,3,4],True]
# for elemento in ls:
#     print(elemento)
#
# print ('longitud: ', len(ls))

for i in range(0,15,2):
    print(i)
