# COMPUTAICON_GRAFICA_2019_2
Para subir todo lo de compu grafica :3 y no tener que preocuparme luego xd
